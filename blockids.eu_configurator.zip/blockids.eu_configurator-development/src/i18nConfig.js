const i18nConfig = {
    locales: ['cs', 'en', 'de'],
    defaultLocale: 'cs',
    prefixDefault: true,
};

module.exports = i18nConfig;
