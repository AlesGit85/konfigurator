<?php
/**
 * Registrace zákazníků - obousměrná synchronizace konfigurátor ↔ e-shop
 * 
 * VERZE: 1.0.0
 * 
 * CO TO DĚLÁ:
 * 1. REST API endpoint pro registraci z konfiguratoru (POST /blockids/v1/customers/register)
 * 2. Pole "Segment" (Rodina / Veřejný prostor) ve WooCommerce registračním formuláři
 * 3. Pole "Segment" v admin profilu uživatele
 * 4. Při registraci odkudkoli se nastaví blockids_segment_id
 * 
 * INSTALACE:
 * 1. Nahraj tento soubor do: wp-content/plugins/blockids-configurator/includes/class-registration.php
 * 2. Přidej require_once v hlavním souboru pluginu (viz instrukce níže)
 */

if (!defined('ABSPATH')) {
    exit;
}

class BLOCKids_Configurator_Registration {
    
    public static function init() {
        // === E-SHOP REGISTRACE: Přidat pole segmentu ===
        add_action('woocommerce_register_form', array(__CLASS__, 'render_segment_field_on_register'));
        add_action('woocommerce_created_customer', array(__CLASS__, 'save_segment_on_register'), 10, 3);
        add_filter('woocommerce_registration_errors', array(__CLASS__, 'validate_segment_on_register'), 10, 3);
        
        // === ADMIN PROFIL: Zobrazit/uložit segment ===
        add_action('show_user_profile', array(__CLASS__, 'render_segment_field_in_admin'));
        add_action('edit_user_profile', array(__CLASS__, 'render_segment_field_in_admin'));
        add_action('personal_options_update', array(__CLASS__, 'save_segment_in_admin'));
        add_action('edit_user_profile_update', array(__CLASS__, 'save_segment_in_admin'));
        
        // === MY ACCOUNT: Zobrazit segment v účtu zákazníka ===
        add_action('woocommerce_edit_account_form', array(__CLASS__, 'render_segment_field_in_account'));
        add_action('woocommerce_save_account_details', array(__CLASS__, 'save_segment_in_account'));
    }
    
    // =========================================================================
    // REST API ENDPOINT - REGISTRACE Z KONFIGURATORU
    // =========================================================================
    
    /**
     * Registrovat API route
     * Volá se z class-api.php → register_routes()
     */
    public static function register_routes() {
        register_rest_route('blockids/v1', '/customers/register', array(
            'methods'  => 'POST',
            'callback' => array(__CLASS__, 'handle_register'),
            'permission_callback' => '__return_true'
        ));
    }
    
    /**
     * Zpracovat registraci z konfiguratoru
     * 
     * Request body:
     * {
     *   "givenName": "Jan",
     *   "familyName": "Novák",
     *   "email": "jan@example.com",
     *   "password": "heslo123",
     *   "phone": "+420123456789",  // volitelné
     *   "segment": 1               // 1 = Rodina, 2 = Veřejný prostor
     * }
     * 
     * Response (úspěch):
     * {
     *   "id": 123,
     *   "givenName": "Jan",
     *   "familyName": "Novák",
     *   "email": "jan@example.com",
     *   "phone": "+420123456789",
     *   "segment": { "id": 1 },
     *   "token": "jwt.token.here",
     *   "planInProgress": null,
     *   "plans": []
     * }
     */
    public static function handle_register($request) {
        $body = $request->get_json_params();
        
        // Validace povinných polí
        $required = array('givenName', 'familyName', 'email', 'password', 'segment');
        foreach ($required as $field) {
            if (empty($body[$field])) {
                return new WP_Error(
                    'missing_field', 
                    sprintf('Pole "%s" je povinné.', $field), 
                    array('status' => 400)
                );
            }
        }
        
        $email     = sanitize_email($body['email']);
        $password  = $body['password'];
        $firstName = sanitize_text_field($body['givenName']);
        $lastName  = sanitize_text_field($body['familyName']);
        $phone     = isset($body['phone']) ? sanitize_text_field($body['phone']) : '';
        $segment   = (int) $body['segment'];
        
        // Validace emailu
        if (!is_email($email)) {
            return new WP_Error('invalid_email', 'Neplatná e-mailová adresa.', array('status' => 400));
        }
        
        // Kontrola, jestli uživatel už existuje
        if (email_exists($email)) {
            return new WP_Error('email_exists', 'Uživatel s tímto e-mailem již existuje.', array('status' => 409));
        }
        
        if (username_exists($email)) {
            return new WP_Error('username_exists', 'Uživatelské jméno již existuje.', array('status' => 409));
        }
        
        // Validace segmentu
        if (!in_array($segment, array(1, 2))) {
            return new WP_Error('invalid_segment', 'Neplatný segment. Použijte 1 (Rodina) nebo 2 (Veřejný prostor).', array('status' => 400));
        }
        
        // Validace hesla (min. 6 znaků)
        if (strlen($password) < 6) {
            return new WP_Error('weak_password', 'Heslo musí mít alespoň 6 znaků.', array('status' => 400));
        }
        
        // Vytvořit WooCommerce zákazníka
        $user_id = wc_create_new_customer($email, $email, $password);
        
        if (is_wp_error($user_id)) {
            return new WP_Error(
                'registration_failed', 
                $user_id->get_error_message(), 
                array('status' => 500)
            );
        }
        
        // Nastavit jméno, příjmení, telefon a segment
        wp_update_user(array(
            'ID'         => $user_id,
            'first_name' => $firstName,
            'last_name'  => $lastName,
            'display_name' => $firstName . ' ' . $lastName,
        ));
        
        // WooCommerce billing údaje
        update_user_meta($user_id, 'billing_first_name', $firstName);
        update_user_meta($user_id, 'billing_last_name', $lastName);
        update_user_meta($user_id, 'billing_email', $email);
        
        if ($phone) {
            update_user_meta($user_id, 'billing_phone', $phone);
        }
        
        // BLOCKids segment (1 = Rodina, 2 = Veřejný prostor)
        update_user_meta($user_id, 'blockids_segment_id', $segment);
        
        // Vygenerovat JWT token pro okamžité přihlášení v konfiguratoru
        $token = BLOCKids_Configurator_Auth::generate_token($user_id);
        
        if (!$token) {
            return new WP_Error('token_failed', 'Účet vytvořen, ale nepodařilo se vygenerovat token.', array('status' => 500));
        }
        
        // Vrátit response ve formátu, který konfigurátor očekává
        return rest_ensure_response(array(
            'id'             => $user_id,
            'givenName'      => $firstName,
            'familyName'     => $lastName,
            'email'          => $email,
            'phone'          => $phone,
            'segment'        => array('id' => $segment),
            'token'          => $token,
            'planInProgress' => null,
            'plans'          => array()
        ));
    }
    
    // =========================================================================
    // WOOCOMMERCE REGISTRACE - POLE SEGMENTU
    // =========================================================================
    
    /**
     * Zobrazit radio buttony na registrační stránce e-shopu
     */
    public static function render_segment_field_on_register() {
        ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label><?php esc_html_e('Vyberte, do které skupiny patříte', 'blockids-configurator'); ?>&nbsp;<span class="required">*</span></label>
            <span class="blockids-segment-options" style="display: block; margin-top: 8px;">
                <label style="display: block; margin-bottom: 10px; padding: 12px 15px; border: 1px solid #ddd; border-radius: 4px; cursor: pointer; background: #fafafa;">
                    <input type="radio" name="blockids_segment" value="1" 
                        <?php checked(isset($_POST['blockids_segment']) ? $_POST['blockids_segment'] : '', '1'); ?> 
                        style="margin-right: 8px;">
                    <strong><?php esc_html_e('Rodina', 'blockids-configurator'); ?></strong>
                </label>
                <label style="display: block; padding: 12px 15px; border: 1px solid #ddd; border-radius: 4px; cursor: pointer; background: #fafafa;">
                    <input type="radio" name="blockids_segment" value="2" 
                        <?php checked(isset($_POST['blockids_segment']) ? $_POST['blockids_segment'] : '', '2'); ?> 
                        style="margin-right: 8px;">
                    <strong><?php esc_html_e('Veřejný prostor', 'blockids-configurator'); ?></strong>
                    <span style="display: block; margin-left: 26px; color: #666; font-size: 0.9em;">
                        <?php esc_html_e('mateřské a základní školy, domovy dětí a mládeže a další', 'blockids-configurator'); ?>
                    </span>
                </label>
            </span>
        </p>
        <?php
    }
    
    /**
     * Validace segmentu při registraci
     */
    public static function validate_segment_on_register($errors, $username, $email) {
        if (empty($_POST['blockids_segment']) || !in_array($_POST['blockids_segment'], array('1', '2'))) {
            $errors->add('blockids_segment_error', __('Vyberte prosím, do které skupiny patříte (Rodina nebo Veřejný prostor).', 'blockids-configurator'));
        }
        return $errors;
    }
    
    /**
     * Uložit segment při registraci
     */
    public static function save_segment_on_register($customer_id, $new_customer_data, $password_generated) {
        if (isset($_POST['blockids_segment'])) {
            $segment = (int) $_POST['blockids_segment'];
            if (in_array($segment, array(1, 2))) {
                update_user_meta($customer_id, 'blockids_segment_id', $segment);
            }
        }
    }
    
    // =========================================================================
    // ADMIN PROFIL - SEGMENT
    // =========================================================================
    
    /**
     * Zobrazit pole segmentu v admin profilu uživatele
     */
    public static function render_segment_field_in_admin($user) {
        $segment = (int) get_user_meta($user->ID, 'blockids_segment_id', true);
        ?>
        <h3><?php esc_html_e('BLOCKids Konfigurátor', 'blockids-configurator'); ?></h3>
        <table class="form-table">
            <tr>
                <th><label><?php esc_html_e('Typ zákazníka', 'blockids-configurator'); ?></label></th>
                <td>
                    <label style="display: block; margin-bottom: 5px;">
                        <input type="radio" name="blockids_segment_id" value="1" <?php checked($segment, 1); ?>>
                        🏠 <?php esc_html_e('Rodina (Domácnost)', 'blockids-configurator'); ?>
                    </label>
                    <label style="display: block;">
                        <input type="radio" name="blockids_segment_id" value="2" <?php checked($segment, 2); ?>>
                        🏢 <?php esc_html_e('Veřejný prostor', 'blockids-configurator'); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e('Typ zákazníka ovlivňuje, které produkty se mu zobrazí v konfiguratoru.', 'blockids-configurator'); ?>
                    </p>
                </td>
            </tr>
        </table>
        <?php
    }
    
    /**
     * Uložit segment v admin profilu
     */
    public static function save_segment_in_admin($user_id) {
        if (!current_user_can('edit_user', $user_id)) {
            return;
        }
        if (isset($_POST['blockids_segment_id'])) {
            $segment = (int) $_POST['blockids_segment_id'];
            if (in_array($segment, array(1, 2))) {
                update_user_meta($user_id, 'blockids_segment_id', $segment);
            }
        }
    }
    
    // =========================================================================
    // MŮJ ÚČET - SEGMENT (read-only info)
    // =========================================================================
    
    /**
     * Zobrazit segment v "Můj účet" → editace údajů
     */
    public static function render_segment_field_in_account() {
        $user_id = get_current_user_id();
        $segment = (int) get_user_meta($user_id, 'blockids_segment_id', true);
        ?>
        <fieldset>
            <legend><?php esc_html_e('Typ zákazníka (BLOCKids)', 'blockids-configurator'); ?></legend>
            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label style="display: block; margin-bottom: 8px;">
                    <input type="radio" name="blockids_segment_id" value="1" <?php checked($segment, 1); ?>>
                    <?php esc_html_e('Rodina', 'blockids-configurator'); ?>
                </label>
                <label style="display: block;">
                    <input type="radio" name="blockids_segment_id" value="2" <?php checked($segment, 2); ?>>
                    <?php esc_html_e('Veřejný prostor', 'blockids-configurator'); ?> 
                    <span style="color: #666; font-size: 0.9em;">(<?php esc_html_e('školy, domovy dětí apod.', 'blockids-configurator'); ?>)</span>
                </label>
            </p>
        </fieldset>
        <?php
    }
    
    /**
     * Uložit segment z "Můj účet"
     */
    public static function save_segment_in_account($user_id) {
        if (isset($_POST['blockids_segment_id'])) {
            $segment = (int) $_POST['blockids_segment_id'];
            if (in_array($segment, array(1, 2))) {
                update_user_meta($user_id, 'blockids_segment_id', $segment);
            }
        }
    }
}