<?php
/**
 * Admin settings page
 * 
 * VERZE: 2.1.0
 * 
 * ZMĚNY:
 * - Testovací link jde přes ?blockids_launch=1 (nastaví cookie)
 * - Dokumentace k shortcode [blockids_configurator_button]
 */

if (!defined('ABSPATH')) {
    exit;
}

class BLOCKids_Configurator_Settings {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_menu_page'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Product meta fields
        add_action('woocommerce_product_options_general_product_data', array($this, 'add_product_meta_fields'));
        add_action('woocommerce_process_product_meta', array($this, 'save_product_meta_fields'));
    }
    
    public function add_menu_page() {
        add_menu_page(
            __('BLOCKids Konfigurátor', 'blockids-configurator'),
            __('BLOCKids', 'blockids-configurator'),
            'manage_options',
            'blockids-configurator',
            array($this, 'render_settings_page'),
            'dashicons-admin-tools',
            56
        );
    }
    
    public function register_settings() {
        register_setting('blockids_configurator_settings', 'blockids_configurator_url');
        register_setting('blockids_configurator_settings', 'blockids_api_base_url');
        register_setting('blockids_configurator_settings', 'blockids_jwt_secret_key');
        register_setting('blockids_configurator_settings', 'blockids_jwt_expiration');
    }
    
    public function add_product_meta_fields() {
        global $post;
        
        echo '<div class="options_group" style="border-top: 1px solid #eee; padding-top: 10px;">';
        echo '<h4 style="padding-left: 12px; color: #0073aa;">' . __('BLOCKids Konfigurátor', 'blockids-configurator') . '</h4>';
        
        woocommerce_wp_select(array(
            'id' => '_blockids_type',
            'label' => __('Typ desky', 'blockids-configurator'),
            'description' => __('Typ pro konfigurátor (jen pro desky)', 'blockids-configurator'),
            'desc_tip' => true,
            'options' => array(
                '' => __('— Nevybráno —', 'blockids-configurator'),
                'rectangle' => __('Obdélník (rectangle)', 'blockids-configurator'),
                'triangle' => __('Trojúhelník (triangle)', 'blockids-configurator'),
                'blackboard' => __('Kreslící tabule (blackboard)', 'blockids-configurator'),
            )
        ));
        
        woocommerce_wp_select(array(
            'id' => '_blockids_location',
            'label' => __('Umístění', 'blockids-configurator'),
            'description' => __('Indoor nebo outdoor (jen pro desky)', 'blockids-configurator'),
            'desc_tip' => true,
            'options' => array(
                '' => __('— Nevybráno —', 'blockids-configurator'),
                'indoor' => __('Indoor', 'blockids-configurator'),
                'outdoor' => __('Outdoor', 'blockids-configurator'),
            )
        ));
        
        woocommerce_wp_text_input(array(
            'id' => '_blockids_color',
            'label' => __('Barva (HEX)', 'blockids-configurator'),
            'description' => __('HEX barva pro matrace, např. #FF0000', 'blockids-configurator'),
            'desc_tip' => true,
            'placeholder' => '#000000'
        ));
        
        woocommerce_wp_checkbox(array(
            'id' => '_blockids_personal',
            'label' => __('Osobní (family)', 'blockids-configurator'),
            'description' => __('Zaškrtněte pro family matrace. Nezaškrtnuté = public.', 'blockids-configurator'),
        ));
        
        woocommerce_wp_textarea_input(array(
            'id' => '_blockids_prices',
            'label' => __('Ceny dle šířky (JSON)', 'blockids-configurator'),
            'description' => __('JSON pole pro public matrace: [{"minWidth":0,"maxWidth":300,"price":5000}]', 'blockids-configurator'),
            'desc_tip' => true,
            'placeholder' => '[{"minWidth":0,"maxWidth":300,"price":5000}]'
        ));
        
        woocommerce_wp_textarea_input(array(
            'id' => '_blockids_overlays',
            'label' => __('Overlays (JSON)', 'blockids-configurator'),
            'description' => __('JSON pole overlays pro gripy: [{"id":"1","type":"standard","orientation":"horizontal","rotation":0,"inputs":false,"image":"url"}]', 'blockids-configurator'),
            'desc_tip' => true,
        ));
        
        echo '</div>';
    }
    
    public function save_product_meta_fields($post_id) {
        $fields = array(
            '_blockids_type',
            '_blockids_location', 
            '_blockids_color',
            '_blockids_prices',
            '_blockids_overlays',
        );
        
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        $personal = isset($_POST['_blockids_personal']) ? 'yes' : 'no';
        update_post_meta($post_id, '_blockids_personal', $personal);
    }
    
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (isset($_POST['blockids_settings_submit'])) {
            check_admin_referer('blockids_settings');
            
            update_option('blockids_configurator_url', sanitize_text_field($_POST['configurator_url']));
            update_option('blockids_api_base_url', sanitize_text_field($_POST['api_base_url']));
            update_option('blockids_jwt_secret_key', sanitize_text_field($_POST['jwt_secret_key']));
            update_option('blockids_jwt_expiration', intval($_POST['jwt_expiration']));
            
            echo '<div class="notice notice-success"><p>' . __('Nastavení uloženo.', 'blockids-configurator') . '</p></div>';
        }
        
        $configurator_url = get_option('blockids_configurator_url', 'https://configurator.blockids.eu');
        $api_base_url = get_option('blockids_api_base_url', home_url('/wp-json/blockids/v1'));
        $jwt_secret_key = get_option('blockids_jwt_secret_key');
        $jwt_expiration = get_option('blockids_jwt_expiration', 3600);
        
        // Launch URL (přes WordPress → nastaví cookie → redirect do konfiguratoru)
        $launch_url = add_query_arg('blockids_launch', '1', home_url('/'));
        
        ?>
        <div class="wrap">
            <h1><?php _e('BLOCKids Konfigurátor - Nastavení', 'blockids-configurator'); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('blockids_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="configurator_url"><?php _e('URL Konfiguratoru', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="url" id="configurator_url" name="configurator_url" value="<?php echo esc_attr($configurator_url); ?>" class="regular-text">
                            <p class="description"><?php _e('Např. https://configurator.blockids.eu nebo http://localhost:3000', 'blockids-configurator'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="api_base_url"><?php _e('API Base URL', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="url" id="api_base_url" name="api_base_url" value="<?php echo esc_attr($api_base_url); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="jwt_secret_key"><?php _e('JWT Secret Key', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="jwt_secret_key" name="jwt_secret_key" value="<?php echo esc_attr($jwt_secret_key); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="jwt_expiration"><?php _e('JWT Token Expiration', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="jwt_expiration" name="jwt_expiration" value="<?php echo esc_attr($jwt_expiration); ?>" class="small-text">
                            <p class="description"><?php _e('V sekundách (výchozí: 3600 = 1 hodina)', 'blockids-configurator'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(__('Uložit nastavení', 'blockids-configurator'), 'primary', 'blockids_settings_submit'); ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Testování', 'blockids-configurator'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('Otevřít konfigurátor', 'blockids-configurator'); ?></th>
                    <td>
                        <a href="<?php echo esc_url($launch_url); ?>" target="_blank" class="button button-primary">
                            <?php _e('Spustit konfigurátor (s auto-login cookie)', 'blockids-configurator'); ?>
                        </a>
                        <p class="description">
                            <?php _e('Tento odkaz vygeneruje JWT token, uloží ho do cookie a přesměruje do konfiguratoru. Při návratu z konfiguratoru se cookie použije pro auto-login.', 'blockids-configurator'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            
            <hr>
            
            <h2><?php _e('Shortcode pro web', 'blockids-configurator'); ?></h2>
            <p><?php _e('Použijte shortcode pro vložení tlačítka do stránky nebo Elementor widget:', 'blockids-configurator'); ?></p>
            <pre style="background: #f5f5f5; padding: 15px; border: 1px solid #ddd; display: inline-block;">[blockids_configurator_button]</pre>
            
            <p><?php _e('Nebo s vlastními atributy:', 'blockids-configurator'); ?></p>
            <pre style="background: #f5f5f5; padding: 15px; border: 1px solid #ddd; display: inline-block;">[blockids_configurator_button text="Navrhněte si stěnu" class="button btn-primary" login_text="Přihlaste se"]</pre>
            
            <p><?php _e('Nebo přímý odkaz pro Elementor tlačítko:', 'blockids-configurator'); ?></p>
            <pre style="background: #f5f5f5; padding: 15px; border: 1px solid #ddd; display: inline-block;"><?php echo esc_html($launch_url); ?></pre>
            
            <hr>
            
            <h2><?php _e('API Endpointy', 'blockids-configurator'); ?></h2>
            <table class="widefat" style="max-width: 800px;">
                <thead>
                    <tr>
                        <th>Metoda</th>
                        <th>Endpoint</th>
                        <th>Popis</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td>GET</td><td><code>/customers/me/{token}</code></td><td>Validace zákazníka</td></tr>
                    <tr><td>GET</td><td><code>/grips/{lang}</code></td><td>Chyty</td></tr>
                    <tr><td>GET</td><td><code>/mattresses/{lang}</code></td><td>Matrace</td></tr>
                    <tr><td>GET</td><td><code>/desks/{lang}</code></td><td>Desky</td></tr>
                    <tr><td>GET</td><td><code>/photos/{lang}</code></td><td>Inspirace</td></tr>
                    <tr><td>GET</td><td><code>/faq-items/{lang}</code></td><td>FAQ</td></tr>
                    <tr><td>POST</td><td><code>/plans/create/{lang}/{token}</code></td><td>Nový plán</td></tr>
                    <tr><td>GET</td><td><code>/plans/detail/{lang}/{token}/{hash}</code></td><td>Detail plánu</td></tr>
                    <tr><td>POST</td><td><code>/plans/update/{lang}/{token}/{hash}</code></td><td>Uložit</td></tr>
                    <tr><td>POST</td><td><code>/plans/confirm/{lang}/{token}/{hash}</code></td><td>Potvrdit</td></tr>
                    <tr><td>DELETE</td><td><code>/plans/delete/{lang}/{token}/{hash}</code></td><td>Smazat</td></tr>
                    <tr><td>POST</td><td><code>/plans/clone/{lang}/{token}/{hash}</code></td><td>Klonovat</td></tr>
                    <tr><td>POST</td><td><code>/plans/change-title/{lang}/{token}/{hash}</code></td><td>Přejmenovat</td></tr>
                </tbody>
            </table>
            <p class="description"><?php echo __('Base URL:', 'blockids-configurator') . ' <code>' . esc_html($api_base_url) . '</code>'; ?></p>
            
            <hr>
            
            <h2><?php _e('Nastavení .env konfiguratoru', 'blockids-configurator'); ?></h2>
            <pre style="background: #f5f5f5; padding: 15px; border: 1px solid #ddd;">
API_BASE_PATH="<?php echo esc_html(home_url('/wp-json/blockids/')); ?>"
API_BASE_VERSION="v1"

NEXT_PUBLIC_URL_REDIRECT_PATH_CS="<?php echo esc_html(home_url('/?blockids_confirm=1')); ?>"
NEXT_PUBLIC_URL_REDIRECT_PATH_EN="<?php echo esc_html(home_url('/?blockids_confirm=1')); ?>"
NEXT_PUBLIC_URL_REDIRECT_PATH_DE="<?php echo esc_html(home_url('/?blockids_confirm=1')); ?>"
            </pre>
        </div>
        <?php
    }
}

new BLOCKids_Configurator_Settings();