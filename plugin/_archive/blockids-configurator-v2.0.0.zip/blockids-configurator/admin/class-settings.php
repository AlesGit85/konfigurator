<?php
/**
 * Admin settings page
 * 
 * VERZE: 2.0.0
 * 
 * ZMĚNY:
 * - SSO URL parametr opravený na ?t= (konfigurátor čeká ?t=, ne ?token=)
 * - Přidány product meta fields pro desky/matrace/gripy
 * - Aktualizovaný seznam API endpointů
 */

if (!defined('ABSPATH')) {
    exit;
}

class BLOCKids_Configurator_Settings {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_menu_page'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Product meta fields
        add_action('woocommerce_product_options_general_product_data', array($this, 'add_product_meta_fields'));
        add_action('woocommerce_process_product_meta', array($this, 'save_product_meta_fields'));
    }
    
    public function add_menu_page() {
        add_menu_page(
            __('BLOCKids Konfigurátor', 'blockids-configurator'),
            __('BLOCKids', 'blockids-configurator'),
            'manage_options',
            'blockids-configurator',
            array($this, 'render_settings_page'),
            'dashicons-admin-tools',
            56
        );
    }
    
    public function register_settings() {
        register_setting('blockids_configurator_settings', 'blockids_configurator_url');
        register_setting('blockids_configurator_settings', 'blockids_api_base_url');
        register_setting('blockids_configurator_settings', 'blockids_jwt_secret_key');
        register_setting('blockids_configurator_settings', 'blockids_jwt_expiration');
    }
    
    /**
     * Add BLOCKids meta fields to WooCommerce product editor
     */
    public function add_product_meta_fields() {
        global $post;
        
        echo '<div class="options_group" style="border-top: 1px solid #eee; padding-top: 10px;">';
        echo '<h4 style="padding-left: 12px; color: #0073aa;">' . __('BLOCKids Konfigurátor', 'blockids-configurator') . '</h4>';
        
        // Typ desky (jen pro kategorii desky)
        woocommerce_wp_select(array(
            'id' => '_blockids_type',
            'label' => __('Typ desky', 'blockids-configurator'),
            'description' => __('Typ pro konfigurátor (jen pro desky)', 'blockids-configurator'),
            'desc_tip' => true,
            'options' => array(
                '' => __('— Nevybráno —', 'blockids-configurator'),
                'rectangle' => __('Obdélník (rectangle)', 'blockids-configurator'),
                'triangle' => __('Trojúhelník (triangle)', 'blockids-configurator'),
                'blackboard' => __('Kreslící tabule (blackboard)', 'blockids-configurator'),
            )
        ));
        
        // Umístění (indoor/outdoor)
        woocommerce_wp_select(array(
            'id' => '_blockids_location',
            'label' => __('Umístění', 'blockids-configurator'),
            'description' => __('Indoor nebo outdoor (jen pro desky)', 'blockids-configurator'),
            'desc_tip' => true,
            'options' => array(
                '' => __('— Nevybráno —', 'blockids-configurator'),
                'indoor' => __('Indoor', 'blockids-configurator'),
                'outdoor' => __('Outdoor', 'blockids-configurator'),
            )
        ));
        
        // Barva matrace
        woocommerce_wp_text_input(array(
            'id' => '_blockids_color',
            'label' => __('Barva (HEX)', 'blockids-configurator'),
            'description' => __('HEX barva pro matrace, např. #FF0000', 'blockids-configurator'),
            'desc_tip' => true,
            'placeholder' => '#000000'
        ));
        
        // Personal matrace
        woocommerce_wp_checkbox(array(
            'id' => '_blockids_personal',
            'label' => __('Osobní (family)', 'blockids-configurator'),
            'description' => __('Zaškrtněte pro family matrace. Nezaškrtnuté = public.', 'blockids-configurator'),
        ));
        
        // Prices (JSON) - pro public matrace
        woocommerce_wp_textarea_input(array(
            'id' => '_blockids_prices',
            'label' => __('Ceny dle šířky (JSON)', 'blockids-configurator'),
            'description' => __('JSON pole pro public matrace: [{"minWidth":0,"maxWidth":300,"price":5000}]', 'blockids-configurator'),
            'desc_tip' => true,
            'placeholder' => '[{"minWidth":0,"maxWidth":300,"price":5000}]'
        ));
        
        // Overlays (JSON) - pro gripy a desky
        woocommerce_wp_textarea_input(array(
            'id' => '_blockids_overlays',
            'label' => __('Overlays (JSON)', 'blockids-configurator'),
            'description' => __('JSON pole overlays pro gripy: [{"id":"1","type":"standard","orientation":"horizontal","rotation":0,"inputs":false,"image":"url"}]', 'blockids-configurator'),
            'desc_tip' => true,
        ));
        
        echo '</div>';
    }
    
    /**
     * Save BLOCKids meta fields
     */
    public function save_product_meta_fields($post_id) {
        $fields = array(
            '_blockids_type',
            '_blockids_location', 
            '_blockids_color',
            '_blockids_prices',
            '_blockids_overlays',
        );
        
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        // Checkbox - personal
        $personal = isset($_POST['_blockids_personal']) ? 'yes' : 'no';
        update_post_meta($post_id, '_blockids_personal', $personal);
    }
    
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Handle form submission
        if (isset($_POST['blockids_settings_submit'])) {
            check_admin_referer('blockids_settings');
            
            update_option('blockids_configurator_url', sanitize_text_field($_POST['configurator_url']));
            update_option('blockids_api_base_url', sanitize_text_field($_POST['api_base_url']));
            update_option('blockids_jwt_secret_key', sanitize_text_field($_POST['jwt_secret_key']));
            update_option('blockids_jwt_expiration', intval($_POST['jwt_expiration']));
            
            echo '<div class="notice notice-success"><p>' . __('Nastavení uloženo.', 'blockids-configurator') . '</p></div>';
        }
        
        $configurator_url = get_option('blockids_configurator_url', 'https://configurator.blockids.eu');
        $api_base_url = get_option('blockids_api_base_url', home_url('/wp-json/blockids/v1'));
        $jwt_secret_key = get_option('blockids_jwt_secret_key');
        $jwt_expiration = get_option('blockids_jwt_expiration', 3600);
        
        ?>
        <div class="wrap">
            <h1><?php _e('BLOCKids Konfigurátor - Nastavení', 'blockids-configurator'); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('blockids_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="configurator_url"><?php _e('URL Konfiguratoru', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="url" id="configurator_url" name="configurator_url" value="<?php echo esc_attr($configurator_url); ?>" class="regular-text">
                            <p class="description"><?php _e('Např. https://configurator.blockids.eu', 'blockids-configurator'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="api_base_url"><?php _e('API Base URL', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="url" id="api_base_url" name="api_base_url" value="<?php echo esc_attr($api_base_url); ?>" class="regular-text">
                            <p class="description"><?php _e('URL vašeho WordPress REST API endpointu', 'blockids-configurator'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="jwt_secret_key"><?php _e('JWT Secret Key', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="jwt_secret_key" name="jwt_secret_key" value="<?php echo esc_attr($jwt_secret_key); ?>" class="regular-text">
                            <p class="description"><?php _e('Tajný klíč pro podepisování JWT tokenů', 'blockids-configurator'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="jwt_expiration"><?php _e('JWT Token Expiration', 'blockids-configurator'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="jwt_expiration" name="jwt_expiration" value="<?php echo esc_attr($jwt_expiration); ?>" class="small-text">
                            <p class="description"><?php _e('Platnost tokenu v sekundách (výchozí: 3600 = 1 hodina)', 'blockids-configurator'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('Testování', 'blockids-configurator'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Test JWT Token', 'blockids-configurator'); ?></th>
                        <td>
                            <?php
                            $current_user = wp_get_current_user();
                            $test_token = BLOCKids_Configurator_Auth::generate_token($current_user->ID);
                            ?>
                            <textarea readonly class="large-text" rows="4"><?php echo esc_textarea($test_token); ?></textarea>
                            <p class="description">
                                <?php _e('Testovací token pro aktuálně přihlášeného uživatele.', 'blockids-configurator'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Link do konfiguratoru', 'blockids-configurator'); ?></th>
                        <td>
                            <?php
                            $locale = substr(get_locale(), 0, 2);
                            if (!in_array($locale, array('cs', 'en', 'de'))) {
                                $locale = 'cs';
                            }
                            // OPRAVA: Konfigurátor čeká ?t= parametr, ne ?token=
                            $configurator_test_url = $configurator_url . '/' . $locale . '/sso?t=' . $test_token;
                            ?>
                            <a href="<?php echo esc_url($configurator_test_url); ?>" target="_blank" class="button">
                                <?php _e('Otevřít konfigurátor s tímto tokenem', 'blockids-configurator'); ?>
                            </a>
                            <p class="description">
                                <?php _e('Poznámka: Konfigurátor čeká parametr ?t= (ne ?token=)', 'blockids-configurator'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('API Endpointy', 'blockids-configurator'); ?></th>
                        <td>
                            <ul style="list-style: disc; padding-left: 20px;">
                                <li><code>GET <?php echo esc_html($api_base_url); ?>/customers/me/{token}</code> — Validace zákazníka</li>
                                <li><code>GET <?php echo esc_html($api_base_url); ?>/grips/cs</code> — Chyty</li>
                                <li><code>GET <?php echo esc_html($api_base_url); ?>/mattresses/cs</code> — Matrace</li>
                                <li><code>GET <?php echo esc_html($api_base_url); ?>/desks/cs</code> — Desky</li>
                                <li><code>GET <?php echo esc_html($api_base_url); ?>/photos/cs</code> — Inspirace</li>
                                <li><code>GET <?php echo esc_html($api_base_url); ?>/faq-items/cs</code> — FAQ</li>
                                <li><code>POST <?php echo esc_html($api_base_url); ?>/plans/create/cs/{token}</code> — Nový plán</li>
                                <li><code>GET <?php echo esc_html($api_base_url); ?>/plans/detail/cs/{token}/{hash}</code> — Detail plánu</li>
                                <li><code>POST <?php echo esc_html($api_base_url); ?>/plans/update/cs/{token}/{hash}</code> — Uložit</li>
                                <li><code>POST <?php echo esc_html($api_base_url); ?>/plans/confirm/cs/{token}/{hash}</code> — Potvrdit</li>
                                <li><code>DELETE <?php echo esc_html($api_base_url); ?>/plans/delete/cs/{token}/{hash}</code> — Smazat</li>
                                <li><code>POST <?php echo esc_html($api_base_url); ?>/plans/clone/cs/{token}/{hash}</code> — Klonovat</li>
                                <li><code>POST <?php echo esc_html($api_base_url); ?>/plans/change-title/cs/{token}/{hash}</code> — Přejmenovat</li>
                            </ul>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(__('Uložit nastavení', 'blockids-configurator'), 'primary', 'blockids_settings_submit'); ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Kategorie produktů', 'blockids-configurator'); ?></h2>
            <p><?php _e('Pro správnou funkci vytvořte v WooCommerce tyto kategorie:', 'blockids-configurator'); ?></p>
            <ul style="list-style: disc; padding-left: 20px;">
                <li><strong>gripy</strong> — <?php _e('Lezecké chyty', 'blockids-configurator'); ?></li>
                <li><strong>matrace</strong> — <?php _e('Dopadové matrace', 'blockids-configurator'); ?></li>
                <li><strong>desky</strong> — <?php _e('Panely/desky lezecké stěny', 'blockids-configurator'); ?></li>
            </ul>
            
            <h2><?php _e('Product meta pole', 'blockids-configurator'); ?></h2>
            <p><?php _e('Při editaci produktů najdete sekci "BLOCKids Konfigurátor" v Obecných datech produktu:', 'blockids-configurator'); ?></p>
            <ul style="list-style: disc; padding-left: 20px;">
                <li><strong><?php _e('Typ desky', 'blockids-configurator'); ?></strong> — rectangle / triangle / blackboard (jen pro desky)</li>
                <li><strong><?php _e('Umístění', 'blockids-configurator'); ?></strong> — indoor / outdoor (jen pro desky)</li>
                <li><strong><?php _e('Barva', 'blockids-configurator'); ?></strong> — HEX barva matrace (jen pro matrace)</li>
                <li><strong><?php _e('Osobní', 'blockids-configurator'); ?></strong> — zaškrtněte pro family matrace (jen pro matrace)</li>
                <li><strong><?php _e('Ceny dle šířky', 'blockids-configurator'); ?></strong> — JSON pole pro public matrace</li>
                <li><strong><?php _e('Overlays', 'blockids-configurator'); ?></strong> — JSON pole overlays pro gripy</li>
            </ul>
            
            <hr>
            
            <h2><?php _e('Nastavení .env konfiguratoru', 'blockids-configurator'); ?></h2>
            <p><?php _e('V .env souboru konfiguratoru nastavte:', 'blockids-configurator'); ?></p>
            <pre style="background: #f5f5f5; padding: 15px; border: 1px solid #ddd;">
API_BASE_PATH="<?php echo esc_html(home_url('/wp-json/blockids/')); ?>"
API_BASE_VERSION="v1"

NEXT_PUBLIC_URL_REDIRECT_PATH_CS="<?php echo esc_html(home_url('/kosik')); ?>"
NEXT_PUBLIC_URL_REDIRECT_PATH_EN="<?php echo esc_html(home_url('/en/cart')); ?>"
NEXT_PUBLIC_URL_REDIRECT_PATH_DE="<?php echo esc_html(home_url('/de/warenkorb')); ?>"
            </pre>
        </div>
        <?php
    }
}

new BLOCKids_Configurator_Settings();