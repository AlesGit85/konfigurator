<?php
/**
 * WooCommerce Cart integration
 * 
 * VERZE: 2.1.0
 * 
 * ZMĚNY:
 * - Auto-login přes JWT cookie když se uživatel vrátí z konfiguratoru
 * - Cookie blockids_auth_token se nastaví v handle_sso_launch (hlavní soubor)
 * - Při ?blockids_confirm=1: pokud uživatel není přihlášený, zkusí auto-login z cookie
 */

if (!defined('ABSPATH')) {
    exit;
}

class BLOCKids_Configurator_Cart {
    
    public static function init() {
        // Handle redirect from configurator
        add_action('template_redirect', array(__CLASS__, 'handle_configurator_redirect'));
        
        // Custom price pro plan v košíku
        add_action('woocommerce_before_calculate_totals', array(__CLASS__, 'set_custom_price'), 20, 1);
        
        // Unikátní cart item
        add_filter('woocommerce_add_cart_item_data', array(__CLASS__, 'add_plan_to_cart_item'), 10, 2);
        
        // Display plan data in cart
        add_filter('woocommerce_get_item_data', array(__CLASS__, 'display_plan_in_cart'), 10, 2);
        
        // Add plan data to order
        add_action('woocommerce_checkout_create_order_line_item', array(__CLASS__, 'add_plan_to_order_item'), 10, 4);
        
        // Display plan in order details
        add_action('woocommerce_order_item_meta_end', array(__CLASS__, 'display_plan_in_order'), 10, 3);
    }
    
    /**
     * Handle redirect from configurator
     */
    public static function handle_configurator_redirect() {
        if (isset($_GET['blockids_confirm'])) {
            self::handle_confirm_redirect();
            return;
        }
        
        // Zpětná kompatibilita: ?plan=hash
        if (isset($_GET['plan'])) {
            self::handle_plan_redirect();
            return;
        }
    }
    
    /**
     * Auto-login uživatele z JWT cookie
     * 
     * Když uživatel přijde z konfiguratoru a není přihlášený ve WP,
     * zkusíme ho přihlásit pomocí JWT tokenu uloženého v cookie.
     * Cookie se nastaví při ?blockids_launch (v hlavním souboru pluginu).
     * 
     * @return int User ID, nebo 0 pokud se nepodařilo
     */
    private static function auto_login_from_cookie() {
        // Už je přihlášený?
        $user_id = get_current_user_id();
        if ($user_id) {
            return $user_id;
        }
        
        // Zkusit cookie
        if (empty($_COOKIE['blockids_auth_token'])) {
            return 0;
        }
        
        $token = sanitize_text_field($_COOKIE['blockids_auth_token']);
        
        // Validovat JWT
        $user_data = BLOCKids_Configurator_Auth::validate_token($token);
        
        if (!$user_data || !isset($user_data->user_id)) {
            // Token neplatný nebo expirovaný - smazat cookie
            setcookie('blockids_auth_token', '', time() - 3600, '/');
            return 0;
        }
        
        // Ověřit že uživatel existuje
        $user = get_user_by('id', $user_data->user_id);
        if (!$user) {
            return 0;
        }
        
        // Přihlásit uživatele do WordPressu
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        
        // Smazat auth cookie - jednorázové použití
        setcookie('blockids_auth_token', '', time() - 3600, '/');
        
        return $user->ID;
    }
    
    /**
     * Handler: ?blockids_confirm=1
     * Najde poslední potvrzený plán a přidá do košíku
     */
    private static function handle_confirm_redirect() {
        // Zkusit auto-login pokud uživatel není přihlášený
        $user_id = self::auto_login_from_cookie();
        
        if (!$user_id) {
            // Ani cookie nepomohlo - redirect na login
            wp_redirect(wp_login_url(add_query_arg('blockids_confirm', '1', home_url('/'))));
            exit;
        }
        
        // Najít poslední potvrzený plán
        global $wpdb;
        $table = $wpdb->prefix . 'blockids_plans';
        
        $plan_row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d AND status = 'confirmed' ORDER BY updated_at DESC LIMIT 1",
            $user_id
        ), ARRAY_A);
        
        if (!$plan_row) {
            wc_add_notice(__('Nebyl nalezen žádný potvrzený návrh.', 'blockids-configurator'), 'error');
            wp_redirect(wc_get_page_permalink('shop'));
            exit;
        }
        
        // Formátovat plán
        $plan = BLOCKids_Configurator_Plans::get_plan_by_hash($plan_row['access_hash'], $user_id);
        
        if (!$plan) {
            wc_add_notice(__('Návrh nebyl nalezen.', 'blockids-configurator'), 'error');
            wp_redirect(wc_get_page_permalink('shop'));
            exit;
        }
        
        // Přidat do košíku
        self::add_plan_to_wc_cart($plan);
        
        // Označit plán jako "in_cart"
        $wpdb->update(
            $table,
            array('status' => 'in_cart'),
            array('access_hash' => $plan['accessHash'], 'user_id' => $user_id)
        );
        
        // Přesměrovat na košík
        wp_redirect(wc_get_cart_url());
        exit;
    }
    
    /**
     * Starý handler: ?plan=hash (zpětná kompatibilita)
     */
    private static function handle_plan_redirect() {
        $access_hash = sanitize_text_field($_GET['plan']);
        
        $user_id = self::auto_login_from_cookie();
        
        if (!$user_id) {
            wp_redirect(wp_login_url(add_query_arg('plan', $access_hash, wc_get_cart_url())));
            exit;
        }
        
        $plan = BLOCKids_Configurator_Plans::get_plan_by_hash($access_hash, $user_id);
        
        if (!$plan) {
            wc_add_notice(__('Návrh nebyl nalezen.', 'blockids-configurator'), 'error');
            wp_redirect(wc_get_page_permalink('shop'));
            exit;
        }
        
        self::add_plan_to_wc_cart($plan);
        
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'blockids_plans',
            array('status' => 'in_cart'),
            array('access_hash' => $access_hash, 'user_id' => $user_id)
        );
        
        wp_redirect(wc_get_cart_url());
        exit;
    }
    
    /**
     * Add plan to WooCommerce cart
     */
    private static function add_plan_to_wc_cart($plan) {
        $product_id = self::get_or_create_custom_wall_product();
        
        $orientation_label = $plan['orientation'] === 'horizontal' 
            ? __('Horizontální', 'blockids-configurator') 
            : __('Vertikální', 'blockids-configurator');
        
        $cart_item_data = array(
            'blockids_plan' => array(
                'access_hash' => $plan['accessHash'],
                'title' => $plan['title'],
                'location' => $plan['location'],
                'orientation' => $plan['orientation'],
                'orientation_label' => $orientation_label,
                'dimensions' => $plan['calculatedWidth'] . ' x ' . $plan['calculatedHeight'] . ' cm',
                'custom_dimensions' => $plan['customWidth'] . ' x ' . $plan['customHeight'] . ' cm',
                'grip_title' => $plan['grip'] ? $plan['grip']['title'] : '',
                'grip_quantity' => $plan['gripQuantity'],
                'mattress_title' => $plan['mattress'] ? $plan['mattress']['title'] : '',
                'mattress_quantity' => $plan['mattressQuantity'],
                'total_price' => self::get_plan_total_price($plan),
            )
        );
        
        WC()->cart->add_to_cart($product_id, 1, 0, array(), $cart_item_data);
        
        wc_add_notice(__('Návrh lezecké stěny byl přidán do košíku.', 'blockids-configurator'), 'success');
    }
    
    /**
     * Get total price from database
     */
    private static function get_plan_total_price($plan) {
        global $wpdb;
        $table = $wpdb->prefix . 'blockids_plans';
        
        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT total_price FROM $table WHERE access_hash = %s",
            $plan['accessHash']
        ));
        
        return ($total && (float) $total > 0) ? (float) $total : 0;
    }
    
    /**
     * Get or create virtual product
     */
    private static function get_or_create_custom_wall_product() {
        $product_id = get_option('blockids_custom_wall_product_id');
        
        if ($product_id && get_post($product_id)) {
            return $product_id;
        }
        
        $product = new WC_Product_Simple();
        $product->set_name(__('Vlastní lezecká stěna', 'blockids-configurator'));
        $product->set_slug('vlastni-lezecka-stena');
        $product->set_regular_price(0);
        $product->set_virtual(true);
        $product->set_catalog_visibility('hidden');
        $product->set_status('publish');
        $product_id = $product->save();
        
        update_option('blockids_custom_wall_product_id', $product_id);
        
        return $product_id;
    }
    
    /**
     * Set custom price from plan data
     */
    public static function set_custom_price($cart) {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }
        
        foreach ($cart->get_cart() as $cart_item) {
            if (isset($cart_item['blockids_plan']) && !empty($cart_item['blockids_plan']['total_price'])) {
                $price = (float) $cart_item['blockids_plan']['total_price'];
                if ($price > 0) {
                    $cart_item['data']->set_price($price);
                }
            }
        }
    }
    
    /**
     * Make each plan unique in cart
     */
    public static function add_plan_to_cart_item($cart_item_data, $product_id) {
        if (isset($cart_item_data['blockids_plan'])) {
            $cart_item_data['unique_key'] = md5($cart_item_data['blockids_plan']['access_hash']);
        }
        return $cart_item_data;
    }
    
    /**
     * Display plan details in cart
     */
    public static function display_plan_in_cart($item_data, $cart_item) {
        if (!isset($cart_item['blockids_plan'])) {
            return $item_data;
        }
        
        $plan = $cart_item['blockids_plan'];
        
        $item_data[] = array(
            'name' => __('Konfigurace', 'blockids-configurator'),
            'value' => $plan['title']
        );
        
        $item_data[] = array(
            'name' => __('Rozměry', 'blockids-configurator'),
            'value' => $plan['dimensions']
        );
        
        $item_data[] = array(
            'name' => __('Orientace', 'blockids-configurator'),
            'value' => $plan['orientation_label']
        );
        
        if (!empty($plan['grip_title'])) {
            $item_data[] = array(
                'name' => __('Chyty', 'blockids-configurator'),
                'value' => $plan['grip_title'] . ' (' . $plan['grip_quantity'] . 'x)'
            );
        }
        
        if (!empty($plan['mattress_title'])) {
            $item_data[] = array(
                'name' => __('Matrace', 'blockids-configurator'),
                'value' => $plan['mattress_title'] . ' (' . $plan['mattress_quantity'] . 'x)'
            );
        }
        
        return $item_data;
    }
    
    /**
     * Add plan data to order item
     */
    public static function add_plan_to_order_item($item, $cart_item_key, $values, $order) {
        if (isset($values['blockids_plan'])) {
            $item->add_meta_data('_blockids_plan', $values['blockids_plan'], true);
        }
    }
    
    /**
     * Display plan in order details
     */
    public static function display_plan_in_order($item_id, $item, $order) {
        $plan = $item->get_meta('_blockids_plan');
        
        if (!$plan) {
            return;
        }
        
        echo '<div class="blockids-plan-details" style="margin-top: 10px; padding: 10px; background: #f5f5f5; border-radius: 4px;">';
        echo '<strong>' . __('Konfigurace lezecké stěny:', 'blockids-configurator') . '</strong><br>';
        echo __('Název:', 'blockids-configurator') . ' ' . esc_html($plan['title']) . '<br>';
        echo __('Rozměry:', 'blockids-configurator') . ' ' . esc_html($plan['dimensions']) . '<br>';
        echo __('Orientace:', 'blockids-configurator') . ' ' . esc_html($plan['orientation_label']) . '<br>';
        
        if (!empty($plan['grip_title'])) {
            echo __('Chyty:', 'blockids-configurator') . ' ' . esc_html($plan['grip_title']) . ' (' . esc_html($plan['grip_quantity']) . 'x)<br>';
        }
        
        if (!empty($plan['mattress_title'])) {
            echo __('Matrace:', 'blockids-configurator') . ' ' . esc_html($plan['mattress_title']) . ' (' . esc_html($plan['mattress_quantity']) . 'x)<br>';
        }
        
        echo '</div>';
    }
}